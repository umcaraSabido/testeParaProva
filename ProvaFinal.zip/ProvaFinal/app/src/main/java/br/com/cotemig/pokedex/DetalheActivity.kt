package br.com.cotemig.pokedex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetalheActivity : AppCompatActivity() {
    private var nome: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhe)

        findViewById<ImageView>(R.id.ivVoltar).setOnClickListener { finish() }
        nome = intent.getStringExtra("nomePokemon").toString()

        //Implementar o metodo get para buscar os dados do pokemon e preencher os dados na tela

    }

    override fun onResume() {
        super.onResume()
        loadPokemon()
    }

    fun loadPokemon(){
        val retrofit = RetrofitUtils.getRetrofitInstance("https://api-brkshm5xha-uc.a.run.app/pokemon/")
        val endpoint = retrofit.create(EndPoint_Pokemon::class.java)

        val contexto = this

        endpoint.getPokemonName(nome).enqueue(object : Callback<PokemonModel> {
            override fun onResponse(
                call: Call<PokemonModel>,
                response: Response<PokemonModel>
            ){
                val pokemon = response.body()

                if(pokemon != null) {
                    findViewById<TextView>(R.id.tvInfo1).setText(pokemon.abilities.first())
                    findViewById<TextView>(R.id.tvNome).setText(pokemon.name)
                    findViewById<TextView>(R.id.tvAltura).setText(pokemon.height).toString()
                    findViewById<TextView>(R.id.tvPeso).setText(pokemon.weight).toString()
                    Glide
                        .with(contexto)
                        .load(pokemon.url)
                        .into(findViewById(R.id.ivPokemon));
                } else {
                    Toast.makeText(contexto, "Não foi possível carregar os dados.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<PokemonModel>, t: Throwable){
                Toast.makeText(contexto, "Deu Erro na Api", Toast.LENGTH_SHORT).show()
            }
        })
    }
}