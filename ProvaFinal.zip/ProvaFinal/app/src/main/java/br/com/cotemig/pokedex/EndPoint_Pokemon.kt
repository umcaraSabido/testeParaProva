package br.com.cotemig.pokedex

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface EndPoint_Pokemon {

    @GET("/pokemon/")
    fun get() : Call<ArrayList<PokemonModel>>

    @GET("/pokemon/{name}")
    fun getPokemonName(@Path("name") name: String?) : Call<PokemonModel>
}