package br.com.cotemig.pokedex

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    override fun onResume() {
        super.onResume()
        loadPokemon()
    }


    fun loadPokemon(){
        val retrofit = RetrofitUtils.getRetrofitInstance("https://api-brkshm5xha-uc.a.run.app/pokemon/")
        val endpoint = retrofit.create(EndPoint_Pokemon::class.java)

        val contexto = this

        endpoint.get().enqueue(object : Callback<ArrayList<PokemonModel>>{
            override fun onResponse(
                call: Call<ArrayList<PokemonModel>>,
                response: Response<ArrayList<PokemonModel>>
            ){
                val pokemon = response.body()

                if(pokemon != null) {
                    showOnList(pokemon)
                } else {
                    Toast.makeText(contexto, "Não foi possível carregar os dados.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ArrayList<PokemonModel>>, t: Throwable){
                Toast.makeText(contexto, "Deu Erro na Api", Toast.LENGTH_SHORT).show()
            }
        })
    }

    fun showOnList(lista: ArrayList<PokemonModel>){
        val recycler = findViewById<RecyclerView>(R.id.rvPokemon)

        val adapter = PokemonAdapter(this, lista, this)

        recycler.adapter = adapter
        recycler.itemAnimator = DefaultItemAnimator()
        recycler.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false)
        recycler.layoutManager = GridLayoutManager(this, 2)
    }

    fun onItemClick(position: Int) {
        val recyclerView = findViewById<RecyclerView>(R.id.rvPokemon)
        val adapter = recyclerView.adapter as? PokemonAdapter
        if (adapter != null) {
            val clickedUser = adapter.lista[position]
            val nomePokemon = clickedUser.name
            val intent = Intent(this, DetalheActivity::class.java)
            intent.putExtra("nomePokemon", nomePokemon)
            startActivity(intent)
        }
    }
}