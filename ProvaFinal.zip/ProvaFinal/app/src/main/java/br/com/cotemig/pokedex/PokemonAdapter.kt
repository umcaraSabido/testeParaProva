package br.com.cotemig.pokedex

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class PokemonAdapter(val contexto: Context, val lista: ArrayList<PokemonModel>, private val listener: MainActivity) :
    RecyclerView.Adapter<PokemonAdapter.ViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        //Implementar aqui o findviewById para buscar os elementos que serão preenchidos na lista
        val ivPokemon = view.findViewById<ImageView>(R.id.ivPokemon)
        val tvNome = view.findViewById<TextView>(R.id.tvNome)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(contexto).inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Implementar aqui o binding das informações no layout

        holder.tvNome.text = lista[position].name

        Glide
            .with(contexto)
            .load(lista[position].url)
            .into(holder.ivPokemon);

        holder.itemView.setOnClickListener {
            listener.onItemClick(position)
        }
    }
}