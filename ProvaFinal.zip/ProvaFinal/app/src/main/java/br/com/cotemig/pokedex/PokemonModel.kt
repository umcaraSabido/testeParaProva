package br.com.cotemig.pokedex

class PokemonModel {
    var id: Int = 0
    var url: String = ""
    var height: Int = 0
    var weight: Int = 0
    var name: String = ""
    var abilities: ArrayList<String> = ArrayList<String>()
}